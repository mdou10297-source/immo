<?php
include 'config.php';

$id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM Livres WHERE id = ?");
$stmt->execute([$id]);
$livre = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$livre) {
    header('Location: index.php');
    exit;
}

// Vérifier si le livre est disponible
$stmt = $pdo->prepare("SELECT COUNT(*) FROM Liste_Lecture WHERE id_livre = ? AND date_retour IS NULL");
$stmt->execute([$id]);
$emprunts_en_cours = $stmt->fetchColumn();
$disponible = ($livre['nombre_exemplaire'] - $emprunts_en_cours) > 0;

// Traitement de l'emprunt
if ($_POST && isset($_POST['emprunter'])) {
    $id_lecteur = 1; // Lecteur par défaut

    if ($disponible) {
        $stmt = $pdo->prepare("INSERT INTO Liste_Lecture (id_livre, id_lecteur, date_emprunt, statut) VALUES (?, ?, CURDATE(), 'emprunté')");
        $stmt->execute([$id, $id_lecteur]);

        header('Location: wishlist.php?success=emprunt');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($livre['titre']) ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Bibliothèque</div>
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="wishlist.php">Mes Emprunts</a></li>
                <li><a href="admin.php">Administration</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="book-details">
            <h1><?= htmlspecialchars($livre['titre']) ?></h1>
            <p class="author">par <?= htmlspecialchars($livre['auteur']) ?></p>

            <div class="book-info">
                <p><strong>Maison d'édition:</strong> <?= htmlspecialchars($livre['maison_edition']) ?></p>
                <p><strong>Exemplaires disponibles:</strong>
                    <?= $livre['nombre_exemplaire'] - $emprunts_en_cours ?> / <?= $livre['nombre_exemplaire'] ?>
                </p>
                <p><strong>Statut:</strong>
                    <span style="color: <?= $disponible ? 'green' : 'red' ?>;">
                        <?= $disponible ? '🟢 Disponible' : '🔴 Indisponible' ?>
                    </span>
                </p>
            </div>

            <div class="description">
                <h3>Description</h3>
                <p><?= nl2br(htmlspecialchars($livre['description'])) ?></p>
            </div>

            <?php if ($disponible): ?>
            <form method="POST" class="emprunt-form">
                <button type="submit" name="emprunter" class="btn btn-primary">
                    📚 Emprunter ce livre
                </button>
            </form>
            <?php else: ?>
            <div class="alert alert-warning">
                <p>❌ Ce livre n'est pas disponible pour le moment.</p>
                <p><small>Date de retour prévue:
                    <?php
                    $stmt = $pdo->prepare("SELECT DATE_ADD(date_emprunt, INTERVAL 21 DAY) as retour_prevu
                      FROM Liste_Lecture
                      WHERE id_livre = ? AND date_retour IS NULL
                      ORDER BY date_emprunt DESC LIMIT 1");
                    $stmt->execute([$id]);
                    $retour = $stmt->fetch(PDO::FETCH_ASSOC);
                    echo $retour ? $retour['retour_prevu'] : 'Inconnue';
                    ?>
                </small></p>
            </div>
            <?php endif; ?>

            <a href="index.php" class="btn">← Retour à l'accueil</a>
        </div>
    </main>
</body>
</html>
