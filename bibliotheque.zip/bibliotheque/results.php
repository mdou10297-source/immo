<?php
include 'config.php';

$search = $_GET['search'] ?? '';

if (!empty($search)) {
    $stmt = $pdo->prepare("SELECT * FROM Livres WHERE titre LIKE ? OR auteur LIKE ?");
    $stmt->execute(["%$search%", "%$search%"]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $results = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Résultats de Recherche</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Bibliothèque D-CjC</div>
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="wishlist.php">Ma Liste</a></li>
                <li><a href="admin.php">Administration</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Résultats de recherche pour "<?= htmlspecialchars($search) ?>"</h1>

        <?php if (empty($results)): ?>
            <p>Aucun livre trouvé pour votre recherche.</p>
        <?php else: ?>
            <div class="books-grid">
                <?php foreach($results as $livre): ?>
                <div class="book-card">
                    <h3><?= htmlspecialchars($livre['titre']) ?></h3>
                    <p class="author"><?= htmlspecialchars($livre['auteur']) ?></p>
                    <p><?= substr(htmlspecialchars($livre['description']), 0, 100) ?>...</p>
                    <div class="actions">
                        <a href="details.php?id=<?= $livre['id'] ?>" class="btn btn-primary">Voir détails</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <a href="index.php" class="btn btn-primary">Retour à l'accueil</a>
    </main>
</body>
</html>
