<?php
// Configuration de la base de données
$host = 'localhost';
$dbname = 'bibliotheque';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    // Message d'erreur convivial
    die("
        <div style='
            padding: 2rem;
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            border-radius: 10px;
            max-width: 600px;
            margin: 2rem auto;
            font-family: Arial, sans-serif;
        '>
            <h2>❌ Erreur de connexion à la base de données</h2>
            <p><strong>Message :</strong> " . $e->getMessage() . "</p>
            <p><strong>Solution :</strong></p>
            <ol>
                <li>Vérifiez que MySQL est démarré dans XAMPP/WAMP</li>
                <li>Importez le fichier database/bibliotheque.sql dans PHPMyAdmin</li>
                <li>Vérifiez les paramètres de connexion dans config.php</li>
            </ol>
            <p><a href='database/bibliotheque.sql' style='color: #007bff;'>📥 Télécharger le script SQL</a></p>
        </div>
    ");
}
?>
