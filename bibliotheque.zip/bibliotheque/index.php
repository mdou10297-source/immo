<?php
include 'config.php';

// Récupération des livres pour affichage
$stmt = $pdo->query("SELECT * FROM Livres LIMIT 6");
$livres = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bibliothèque en Ligne - Accueil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Bibliothèque Baniko</div>
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="wishlist.php">Ma Liste</a></li>
                <li><a href="admin.php">Administration</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section class="hero">
            <h1>Bienvenue à la Bibliothèque Baniko</h1>
            <p>Découvrez notre vaste collection de livres et gérez votre liste de lecture</p>
        </section>

        <form action="results.php" method="GET" class="search-form">
            <input type="text" name="search" placeholder="Rechercher un livre par titre ou auteur...">
            <button type="submit">Rechercher</button>
        </form>

        <section>
            <h2>Livres Populaires</h2>
            <div class="books-grid">
                <?php foreach($livres as $livre): ?>
                <div class="book-card">
                    <h3><?= htmlspecialchars($livre['titre']) ?></h3>
                    <p class="author"><?= htmlspecialchars($livre['auteur']) ?></p>
                    <p><?= substr(htmlspecialchars($livre['description']), 0, 100) ?>...</p>
                    <div class="actions">
                        <a href="details.php?id=<?= $livre['id'] ?>" class="btn btn-primary">Voir détails</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <script src="script.js"></script>
</body>
</html>
