-- Création de la base de données
CREATE DATABASE IF NOT EXISTS bibliotheque CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bibliotheque;

-- Table Livres
CREATE TABLE Livres (
    id INT PRIMARY KEY AUTO_INCREMENT,
    titre VARCHAR(100) NOT NULL,
    auteur VARCHAR(100) NOT NULL,
    description TEXT,
    maison_edition VARCHAR(100),
    nombre_exemplaire INT DEFAULT 1
);

-- Table Lecteurs
CREATE TABLE Lecteurs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL
);

-- Table Liste_Lecture
CREATE TABLE Liste_Lecture (
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_livre INT,
    id_lecteur INT,
    date_emprunt DATE NOT NULL,
    date_retour DATE NULL,
    statut ENUM('emprunté', 'rendu') DEFAULT 'emprunté',
    FOREIGN KEY (id_livre) REFERENCES Livres(id) ON DELETE CASCADE,
    FOREIGN KEY (id_lecteur) REFERENCES Lecteurs(id) ON DELETE CASCADE
);

-- Insertion des livres d'écrivains africains
INSERT INTO Livres (titre, auteur, description, maison_edition, nombre_exemplaire) VALUES
('L''Enfant noir', 'Camara Laye', 'Roman autobiographique racontant l''enfance et l''adolescence de l''auteur en Guinée', 'Plon', 5),
('Le Cercle des Tropiques', 'Thierno Monenembo', 'Une fresque historique sur la Guinée précoloniale et coloniale', 'Seuil', 3),
('Chants d''ombre', 'Léopold Sédar Senghor', 'Recueil de poèmes célébrant la négritude et les racines africaines', 'Seuil', 6),
('L''Étrange Destin de Wangrin', 'Amadou Hampâté Bâ', 'Roman basé sur la vie d''un célèbre interprète et commerçant en Afrique de l''Ouest', 'Union Générale d''Éditions', 4),
('L''Aventure ambiguë', 'Cheikh Hamidou Kane', 'Roman philosophique sur la confrontation entre culture africaine et occidentale', 'Julliard', 3),
('Les Bouts de bois de Dieu', 'Ousmane Sembène', 'Roman sur la grève des cheminots du Dakar-Niger en 1947-1948', 'Le Livre Contemporain', 5),
('Une si longue lettre', 'Mariama Bâ', 'Roman épistolaire sur la condition des femmes au Sénégal', 'Nouvelles Éditions Africaines', 4),
('Le Monde s''effondre', 'Chinua Achebe', 'Roman majeur de la littérature africaine sur l''impact du colonialisme', 'Heinemann', 6),
('La République des sables', 'Aliou Bah', 'Réflexion sur la gouvernance et la démocratie en Afrique contemporaine', 'L''Harmattan', 3),
('Les Impatients', 'Foniké Mengué', 'Roman sur la jeunesse africaine face aux défis de la modernité', 'Éditions CLE', 4),
('Le Roi de Kahel', 'Tierno Monénembo', 'Roman historique sur l''explorateur Aimé Olivier de Sanderval', 'Seuil', 3),
('L''Appel des arènes', 'Aminata Sow Fall', 'Roman sur la tradition de la lutte sénégalaise dans la société moderne', 'Nouvelles Éditions Africaines', 5),
('Le Pleurer-Rire', 'Henri Lopes', 'Satire politique sur les dictatures africaines post-coloniales', 'Présence Africaine', 4),
('La Mémoire amputée', 'Werewere Liking', 'Réflexion sur l''identité culturelle et la mémoire collective', 'Nouvelles Éditions Ivoiriennes', 3),
('Les Soleils des indépendances', 'Ahmadou Kourouma', 'Critique des régimes post-coloniaux en Afrique de l''Ouest', 'Seuil', 5),
('Le Cahier de Rome', 'Thiaone Ngnang', 'Récit de voyage et réflexion sur la diaspora africaine', 'Éditions Mémoire d''Encrier', 4),
('La Promesse des fleurs', 'Fatou Keïta', 'Roman sur la résilience et l''espoir dans l''Afrique contemporaine', 'Nouvelles Éditions Ivoiriennes', 3),
('Le Ventre de l''Atlantique', 'Fatou Diome', 'Roman sur l''immigration et les rêves de la jeunesse sénégalaise', 'Anne Carrière', 6),
('Père riche, Père pauvre', 'Robert Kiyosaki', 'Guide d''éducation financière et d''indépendance économique', 'Universe Publishing', 8),
('L''Art de la guerre', 'Sun Tzu', 'Traité de stratégie militaire applicable aux affaires et à la vie', 'Flammarion', 7);

-- Insertion du lecteur par défaut africain
INSERT INTO Lecteurs (nom, prenom, email) VALUES
('Diallo', 'Mamadou Dian', 'mamadou.dian.diallo@email.com');
