# Projet Bibliothèque en Ligne - Littérature Africaine

## Description
Site web de gestion de bibliothèque spécialisé dans la littérature africaine, avec système d'emprunt développé en PHP/MySQL.

## Auteurs Africains Inclus
- Camara Laye, Thierno Monenembo, Léopold Sédar Senghor
- Amadou Hampâté Bâ, Cheikh Hamidou Kane, Ousmane Sembène
- Mariama Bâ, Chinua Achebe, Aliou Bah, Foniké Mengué
- Et bien d'autres...

## Installation

### Prérequis
- Serveur web (XAMPP, WAMP, MAMP)
- PHP 7.4+
- MySQL 5.7+

### Étapes d'installation

1. **Extraire le projet** dans le dossier `htdocs` de XAMPP
2. **Démarrer** Apache et MySQL dans XAMPP
3. **Importer la base de données** :
   - Ouvrir http://localhost/phpmyadmin
   - Créer une base `bibliotheque`
   - Importer le fichier `database/bibliotheque.sql`
4. **Accéder au site** : http://localhost/bibliotheque/

## Utilisation

### Pages principales :
- **Accueil** (`index.php`) : Recherche et découverte de la littérature africaine
- **Mes Emprunts** (`wishlist.php`) : Gestion des emprunts
- **Administration** (`admin.php`) : Gestion des livres (CRUD)

### Compte de test :
- Lecteur par défaut : **Mamadou Dian DIALLO**

## Fonctionnalités Spéciales

- ✅ Collection dédiée à la littérature africaine
- ✅ Recherche par auteur ou titre
- ✅ Système d'emprunt avec gestion des dates
- ✅ Interface adaptée aux œuvres africaines
- ✅ Base de données pré-remplie avec 20 œuvres majeures

## Œuvres Incluses
- *L'Enfant noir* - Camara Laye
- *Chants d'ombre* - Léopold Sédar Senghor
- *L'Étrange Destin de Wangrin* - Amadou Hampâté Bâ
- *Une si longue lettre* - Mariama Bâ
- *Le Monde s'effondre* - Chinua Achebe
- Et 15 autres œuvres importantes...
