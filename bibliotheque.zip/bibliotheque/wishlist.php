<?php
include 'config.php';

$id_lecteur = 1; // Lecteur par défaut

// Récupération des emprunts en cours
$stmt = $pdo->prepare("
    SELECT l.*, ll.id as liste_id, ll.date_emprunt, ll.date_retour, ll.statut,
    DATEDIFF(CURDATE(), ll.date_emprunt) as jours_emprunte
    FROM Liste_Lecture ll
    JOIN Livres l ON ll.id_livre = l.id
    WHERE ll.id_lecteur = ?
    ORDER BY ll.date_emprunt DESC
");
$stmt->execute([$id_lecteur]);
$emprunts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Traitement du retour de livre
if ($_POST && isset($_POST['retourner'])) {
    $liste_id = $_POST['liste_id'];
    $stmt = $pdo->prepare("UPDATE Liste_Lecture SET date_retour = CURDATE(), statut = 'rendu' WHERE id = ?");
    $stmt->execute([$liste_id]);

    header('Location: wishlist.php?success=retour');
    exit;
}

// Traitement de l'emprunt (depuis la page détails)
$success_message = '';
if (isset($_GET['success'])) {
    $success_message = $_GET['success'] == 'emprunt' ?
        '✅ Livre emprunté avec succès!' : '✅ Livre retourné avec succès!';
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Emprunts</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Bibliothèque </div>
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="wishlist.php">Mes Emprunts</a></li>
                <li><a href="admin.php">Administration</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>📚 Mes Emprunts</h1>

        <?php if ($success_message): ?>
            <div class="alert alert-success"><?= $success_message ?></div>
        <?php endif; ?>

        <?php if (empty($emprunts)): ?>
            <div class="empty-state">
                <p>📖 Vous n'avez aucun emprunt en cours.</p>
                <a href="index.php" class="btn btn-primary">Découvrir les livres disponibles</a>
            </div>
        <?php else: ?>
            <div class="emprunts-grid">
                <?php foreach($emprunts as $emprunt): ?>
                <div class="emprunt-card <?= $emprunt['statut'] ?>">
                    <h3><?= htmlspecialchars($emprunt['titre']) ?></h3>
                    <p class="author"><?= htmlspecialchars($emprunt['auteur']) ?></p>

                    <div class="emprunt-info">
                        <p><strong>Emprunté le:</strong> <?= $emprunt['date_emprunt'] ?></p>

                        <?php if ($emprunt['statut'] == 'emprunté'): ?>
                            <p><strong>Jours empruntés:</strong> <?= $emprunt['jours_emprunte'] ?> jours</p>
                            <p><strong>Statut:</strong> <span class="statut-emprunte">🟡 En cours</span></p>

                            <?php if ($emprunt['jours_emprunte'] > 21): ?>
                                <p class="retard" style="color: red;">⚠️ En retard! Merci de retourner le livre.</p>
                            <?php endif; ?>

                            <form method="POST" class="retour-form">
                                <input type="hidden" name="liste_id" value="<?= $emprunt['liste_id'] ?>">
                                <button type="submit" name="retourner" class="btn btn-success">
                                    ✅ Retourner le livre
                                </button>
                            </form>

                        <?php else: ?>
                            <p><strong>Retourné le:</strong> <?= $emprunt['date_retour'] ?></p>
                            <p><strong>Statut:</strong> <span class="statut-rendu">✅ Rendu</span></p>
                        <?php endif; ?>
                    </div>

                    <div class="actions">
                        <a href="details.php?id=<?= $emprunt['id'] ?>" class="btn btn-primary">Voir détails</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <a href="index.php" class="btn">← Retour à l'accueil</a>
    </main>
</body>
</html>
