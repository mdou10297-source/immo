// Gestion des interactions utilisateur
document.addEventListener("DOMContentLoaded", function () {
  // Animation des cartes de livre
  const bookCards = document.querySelectorAll(".book-card");

  bookCards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.style.transform = "translateY(-5px)";
    });

    card.addEventListener("mouseleave", function () {
      this.style.transform = "translateY(0)";
    });
  });

  // Validation des formulaires
  const forms = document.querySelectorAll("form");
  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      const requiredFields = this.querySelectorAll("[required]");
      let valid = true;

      requiredFields.forEach((field) => {
        if (!field.value.trim()) {
          valid = false;
          field.style.borderColor = "red";
        } else {
          field.style.borderColor = "";
        }
      });

      if (!valid) {
        e.preventDefault();
        alert("Veuillez remplir tous les champs obligatoires.");
      }
    });
  });

  // Recherche en temps réel (fonctionnalité bonus)
  const searchInput = document.querySelector('input[name="search"]');
  if (searchInput) {
    searchInput.addEventListener("input", function () {
      // Implémentation possible de la recherche en temps réel
      console.log("Recherche:", this.value);
    });
  }
});
