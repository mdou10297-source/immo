<?php
include 'config.php';

// Opérations CRUD
if ($_POST) {
    // AJOUT d'un livre
    if (isset($_POST['add_book'])) {
        $titre = trim($_POST['titre']);
        $auteur = trim($_POST['auteur']);
        $description = trim($_POST['description']);
        $maison_edition = trim($_POST['maison_edition']);
        $nombre_exemplaire = intval($_POST['nombre_exemplaire']);

        if (!empty($titre) && !empty($auteur)) {
            $stmt = $pdo->prepare("INSERT INTO Livres (titre, auteur, description, maison_edition, nombre_exemplaire) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$titre, $auteur, $description, $maison_edition, $nombre_exemplaire]);
            $message = "✅ Livre ajouté avec succès!";
        } else {
            $error = "❌ Le titre et l'auteur sont obligatoires";
        }
    }

    // MODIFICATION d'un livre (SIMPLIFIÉE)
    elseif (isset($_POST['update_book'])) {
        $stmt = $pdo->prepare("UPDATE Livres SET titre=?, auteur=?, description=?, maison_edition=?, nombre_exemplaire=? WHERE id=?");
        $stmt->execute([
            $_POST['titre'],
            $_POST['auteur'],
            $_POST['description'],
            $_POST['maison_edition'],
            $_POST['nombre_exemplaire'],
            $_POST['id']
        ]);
        $message = "✅ Livre modifié avec succès!";
    }

    // SUPPRESSION d'un livre
    elseif (isset($_POST['delete_book'])) {
        // Vérifier si le livre est emprunté
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM Liste_Lecture WHERE id_livre = ? AND date_retour IS NULL");
        $stmt->execute([$_POST['id']]);
        $emprunts_en_cours = $stmt->fetchColumn();

        if ($emprunts_en_cours > 0) {
            $error = "❌ Impossible de supprimer ce livre : il est actuellement emprunté";
        } else {
            $stmt = $pdo->prepare("DELETE FROM Livres WHERE id=?");
            $stmt->execute([$_POST['id']]);
            $message = "✅ Livre supprimé avec succès!";
        }
    }

    // Redirection pour éviter le re-post
    $redirect_url = 'admin.php';
    if (isset($message)) $redirect_url .= '?message=' . urlencode($message);
    if (isset($error)) $redirect_url .= (strpos($redirect_url, '?') === false ? '?' : '&') . 'error=' . urlencode($error);

    header('Location: ' . $redirect_url);
    exit;
}

// Récupération des messages
$message = $_GET['message'] ?? '';
$error = $_GET['error'] ?? '';

// Récupération de tous les livres
$stmt = $pdo->query("SELECT * FROM Livres ORDER BY titre");
$livres = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupération des statistiques d'emprunts
$stmt = $pdo->query("
    SELECT l.id, COUNT(ll.id) as emprunts_actifs
    FROM Livres l
    LEFT JOIN Liste_Lecture ll ON l.id = ll.id_livre AND ll.date_retour IS NULL
    GROUP BY l.id
");
$stats_emprunts = [];
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($results as $row) {
    $stats_emprunts[$row['id']] = $row['emprunts_actifs'];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administration - Bibliothèque</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">Bibliothèque </div>
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="wishlist.php">Mes Emprunts</a></li>
                <li><a href="admin.php">Administration</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h1>📊 Administration de la Bibliothèque</h1>

        <!-- Messages d'alerte -->
        <?php if ($message): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Section d'ajout de livre -->
        <section class="add-book-section">
            <h2>📖 Ajouter un nouveau livre</h2>
            <form method="POST" class="book-form" id="add-book-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="titre">Titre *</label>
                        <input type="text" id="titre" name="titre" required
                               placeholder="Ex: Le Petit Prince">
                    </div>

                    <div class="form-group">
                        <label for="auteur">Auteur *</label>
                        <input type="text" id="auteur" name="auteur" required
                               placeholder="Ex: Antoine de Saint-Exupéry">
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" rows="4"
                              placeholder="Description du livre..."></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="maison_edition">Maison d'édition</label>
                        <input type="text" id="maison_edition" name="maison_edition"
                               placeholder="Ex: Gallimard">
                    </div>

                    <div class="form-group">
                        <label for="nombre_exemplaire">Nombre d'exemplaires</label>
                        <input type="number" id="nombre_exemplaire" name="nombre_exemplaire"
                               value="1" min="1" max="100">
                    </div>
                </div>

                <button type="submit" name="add_book" class="btn btn-primary">
                    ➕ Ajouter le livre
                </button>
            </form>
        </section>

        <!-- Section de gestion des livres existants (CORRIGÉE ET SIMPLIFIÉE) -->
        <section class="manage-books-section">
            <h2>📚 Gestion des livres existants</h2>

            <?php if (empty($livres)): ?>
                <div class="empty-state">
                    <p>📖 Aucun livre dans la bibliothèque pour le moment.</p>
                    <p>Utilisez le formulaire ci-dessus pour ajouter votre premier livre !</p>
                </div>
            <?php else: ?>
                <div class="books-grid admin-grid">
                    <?php foreach($livres as $livre):
                        $emprunts_actifs = $stats_emprunts[$livre['id']] ?? 0;
                        $disponibles = $livre['nombre_exemplaire'] - $emprunts_actifs;
                    ?>
                    <div class="book-card admin-card">
                        <form method="POST" class="book-form-inline">
                            <input type="hidden" name="id" value="<?= $livre['id'] ?>">

                            <div class="book-header">
                                <h3>#<?= $livre['id'] ?> - <?= htmlspecialchars($livre['titre']) ?></h3>
                                <div class="book-stats">
                                    <span class="badge <?= $disponibles > 0 ? 'badge-success' : 'badge-danger' ?>">
                                        📊 <?= $disponibles ?> / <?= $livre['nombre_exemplaire'] ?> dispo.
                                    </span>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Titre:</label>
                                <input type="text" name="titre" value="<?= htmlspecialchars($livre['titre']) ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Auteur:</label>
                                <input type="text" name="auteur" value="<?= htmlspecialchars($livre['auteur']) ?>" required>
                            </div>

                            <div class="form-group">
                                <label>Description:</label>
                                <textarea name="description" rows="3"><?= htmlspecialchars($livre['description']) ?></textarea>
                            </div>

                            <div class="form-row">
                                <div class="form-group">
                                    <label>Maison d'édition:</label>
                                    <input type="text" name="maison_edition" value="<?= htmlspecialchars($livre['maison_edition']) ?>">
                                </div>

                                <div class="form-group">
                                    <label>Exemplaires:</label>
                                    <input type="number" name="nombre_exemplaire" value="<?= $livre['nombre_exemplaire'] ?>" min="0" max="100">
                                </div>
                            </div>

                            <div class="actions admin-actions">
                                <button type="submit" name="update_book" class="btn btn-primary">
                                    ✏️ Modifier
                                </button>
                                <button type="submit" name="delete_book" class="btn btn-danger"
                                        onclick="return confirm('Êtes-vous sûr de vouloir supprimer le livre « <?= addslashes($livre['titre']) ?> » ?')">
                                    🗑️ Supprimer
                                </button>
                            </div>
                        </form>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <!-- Section statistiques et emprunts -->
        <section class="stats-section">
            <h2>📈 Statistiques</h2>

            <?php
            // Récupération de tous les emprunts
            $stmt = $pdo->query("
                SELECT ll.*, l.titre, lec.nom, lec.prenom
                FROM Liste_Lecture ll
                JOIN Livres l ON ll.id_livre = l.id
                JOIN Lecteurs lec ON ll.id_lecteur = lec.id
                ORDER BY ll.date_emprunt DESC
            ");
            $emprunts = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Calcul des statistiques
            $total_livres = count($livres);
            $emprunts_actifs = count(array_filter($emprunts, fn($e) => $e['date_retour'] === null));
            $emprunts_termines = count(array_filter($emprunts, fn($e) => $e['date_retour'] !== null));
            ?>

            <div class="stats-grid">
                <div class="stat-card">
                    <h3>📚 Livres total</h3>
                    <p class="stat-number"><?= $total_livres ?></p>
                </div>

                <div class="stat-card">
                    <h3>👥 Emprunts actifs</h3>
                    <p class="stat-number"><?= $emprunts_actifs ?></p>
                </div>

                <div class="stat-card">
                    <h3>✅ Emprunts terminés</h3>
                    <p class="stat-number"><?= $emprunts_termines ?></p>
                </div>
            </div>

            <div class="emprunts-admin">
                <h3>📋 Historique des emprunts</h3>

                <?php if (empty($emprunts)): ?>
                    <p>Aucun emprunt enregistré.</p>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Livre</th>
                                <th>Lecteur</th>
                                <th>Date Emprunt</th>
                                <th>Date Retour</th>
                                <th>Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($emprunts as $emprunt): ?>
                            <tr>
                                <td><?= htmlspecialchars($emprunt['titre']) ?></td>
                                <td><?= htmlspecialchars($emprunt['prenom'] . ' ' . $emprunt['nom']) ?></td>
                                <td><?= $emprunt['date_emprunt'] ?></td>
                                <td><?= $emprunt['date_retour'] ?: '—' ?></td>
                                <td>
                                    <span class="badge <?= $emprunt['date_retour'] ? 'badge-success' : 'badge-warning' ?>">
                                        <?= $emprunt['date_retour'] ? 'Rendu' : 'Emprunté' ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <script>
    // Validation simplifiée
    document.addEventListener('DOMContentLoaded', function() {
        // Validation du formulaire d'ajout
        const addForm = document.getElementById('add-book-form');
        if (addForm) {
            addForm.addEventListener('submit', function(e) {
                const requiredFields = this.querySelectorAll('[required]');
                let isValid = true;

                requiredFields.forEach(field => {
                    if (!field.value.trim()) {
                        isValid = false;
                        field.style.borderColor = '#e74c3c';
                    } else {
                        field.style.borderColor = '';
                    }
                });

                if (!isValid) {
                    e.preventDefault();
                    alert('❌ Veuillez remplir tous les champs obligatoires.');
                }
            });
        }

        // Validation des formulaires de modification
        const updateForms = document.querySelectorAll('.book-form-inline');
        updateForms.forEach(form => {
            form.addEventListener('submit', function(e) {
                const submitter = e.submitter;

                if (submitter.name === 'update_book') {
                    // Vérifier les champs requis
                    const requiredFields = form.querySelectorAll('[required]');
                    let isValid = true;

                    requiredFields.forEach(field => {
                        if (!field.value.trim()) {
                            isValid = false;
                            field.style.borderColor = '#e74c3c';
                        } else {
                            field.style.borderColor = '';
                        }
                    });

                    if (!isValid) {
                        e.preventDefault();
                        alert('❌ Veuillez remplir tous les champs obligatoires.');
                        return;
                    }

                    // Confirmation simple
                    if (!confirm('Êtes-vous sûr de vouloir modifier ce livre ?')) {
                        e.preventDefault();
                    }
                }
            });
        });
    });
    </script>
</body>
</html>
